public enum DemoTypes {

    INT, BOOL, UNKNOWN

}

