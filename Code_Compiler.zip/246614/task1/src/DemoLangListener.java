// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DemoLangParser}.
 */
public interface DemoLangListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(DemoLangParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(DemoLangParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#method}.
	 * @param ctx the parse tree
	 */
	void enterMethod(DemoLangParser.MethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#method}.
	 * @param ctx the parse tree
	 */
	void exitMethod(DemoLangParser.MethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#param}.
	 * @param ctx the parse tree
	 */
	void enterParam(DemoLangParser.ParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#param}.
	 * @param ctx the parse tree
	 */
	void exitParam(DemoLangParser.ParamContext ctx);
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(DemoLangParser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(DemoLangParser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(DemoLangParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(DemoLangParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#ene}.
	 * @param ctx the parse tree
	 */
	void enterEne(DemoLangParser.EneContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#ene}.
	 * @param ctx the parse tree
	 */
	void exitEne(DemoLangParser.EneContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(DemoLangParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(DemoLangParser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Int}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterInt(DemoLangParser.IntContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Int}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitInt(DemoLangParser.IntContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Bool}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterBool(DemoLangParser.BoolContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Bool}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitBool(DemoLangParser.BoolContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Assign}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterAssign(DemoLangParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Assign}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitAssign(DemoLangParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Binop}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterBinop(DemoLangParser.BinopContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Binop}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitBinop(DemoLangParser.BinopContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CallFunction}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterCallFunction(DemoLangParser.CallFunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CallFunction}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitCallFunction(DemoLangParser.CallFunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CodeBlock}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterCodeBlock(DemoLangParser.CodeBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CodeBlock}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitCodeBlock(DemoLangParser.CodeBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IfElse}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterIfElse(DemoLangParser.IfElseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IfElse}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitIfElse(DemoLangParser.IfElseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code While}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterWhile(DemoLangParser.WhileContext ctx);
	/**
	 * Exit a parse tree produced by the {@code While}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitWhile(DemoLangParser.WhileContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Repeat}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterRepeat(DemoLangParser.RepeatContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Repeat}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitRepeat(DemoLangParser.RepeatContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Print}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterPrint(DemoLangParser.PrintContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Print}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitPrint(DemoLangParser.PrintContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Space}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterSpace(DemoLangParser.SpaceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Space}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitSpace(DemoLangParser.SpaceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NewLine}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterNewLine(DemoLangParser.NewLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NewLine}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitNewLine(DemoLangParser.NewLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Skip}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterSkip(DemoLangParser.SkipContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Skip}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitSkip(DemoLangParser.SkipContext ctx);
	/**
	 * Enter a parse tree produced by {@link DemoLangParser#args}.
	 * @param ctx the parse tree
	 */
	void enterArgs(DemoLangParser.ArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link DemoLangParser#args}.
	 * @param ctx the parse tree
	 */
	void exitArgs(DemoLangParser.ArgsContext ctx);
}