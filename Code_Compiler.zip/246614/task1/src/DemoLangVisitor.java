// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DemoLangParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DemoLangVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(DemoLangParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#method}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethod(DemoLangParser.MethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParam(DemoLangParser.ParamContext ctx);
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBody(DemoLangParser.BodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(DemoLangParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#ene}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEne(DemoLangParser.EneContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(DemoLangParser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Int}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInt(DemoLangParser.IntContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Bool}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBool(DemoLangParser.BoolContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Assign}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(DemoLangParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Binop}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinop(DemoLangParser.BinopContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CallFunction}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallFunction(DemoLangParser.CallFunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CodeBlock}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCodeBlock(DemoLangParser.CodeBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IfElse}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfElse(DemoLangParser.IfElseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code While}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhile(DemoLangParser.WhileContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Repeat}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRepeat(DemoLangParser.RepeatContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Print}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrint(DemoLangParser.PrintContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Space}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSpace(DemoLangParser.SpaceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NewLine}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewLine(DemoLangParser.NewLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Skip}
	 * labeled alternative in {@link DemoLangParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSkip(DemoLangParser.SkipContext ctx);
	/**
	 * Visit a parse tree produced by {@link DemoLangParser#args}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgs(DemoLangParser.ArgsContext ctx);
}